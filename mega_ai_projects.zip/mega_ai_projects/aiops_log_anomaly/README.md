# AIOps Log Anomaly Detection

## Aim

This project implements a basic **AIOps** pipeline for detecting anomalous log
messages.  AIOps (Artificial Intelligence for IT Operations) uses machine
learning and big data analytics to automate and improve IT operations.
It combines data from logs, metrics and events to identify and respond to
incidents more effectively【677892187559889†L200-L223】.  Key benefits of AIOps
include automation of tasks like anomaly detection and root cause analysis,
data‑driven insights and proactive problem‑solving【677892187559889†L200-L223】.

In this project we focus on the anomaly detection component.  We take a set of
sample log lines, convert them into vector representations using TF‑IDF and
train an **Isolation Forest** model to identify unusual log entries.

## Prerequisites

* **Python 3.9+**
* [pandas](https://pandas.pydata.org/) and [scikit‑learn](https://scikit-learn.org/):
  `pip install pandas scikit-learn`

## Tools & Libraries

| Tool | Purpose |
| --- | --- |
| `pandas` | Handles tabular log data. |
| `scikit-learn` | Provides TF‑IDF vectorizer and Isolation Forest algorithm. |

## Workflow

1. **Load log data** – For demonstration, the script defines a small list of log
   messages containing normal and anomalous entries.  In practice you would
   ingest logs from files or monitoring systems.
2. **Feature extraction** – Convert text logs into numerical feature vectors
   using a TF‑IDF (`Term Frequency–Inverse Document Frequency`) vectorizer.
3. **Model training** – Fit an `IsolationForest` model to the feature vectors.
   This algorithm isolates anomalies by randomly selecting features and
   constructing trees; points requiring fewer splits are considered anomalies.
4. **Prediction** – Apply the model to assign an anomaly score to each log
   entry and label entries as normal or anomalous.
5. **Reporting** – Display the anomalous log entries and optionally write
   them to a file.

## Running the Project

```bash
# Install dependencies
pip install pandas scikit-learn

# Run anomaly detection
python main.py
```

## Extending

To adapt this prototype for real‑world AIOps environments you could:

* Ingest streaming logs from sources like syslog or application logs.
* Combine logs with metrics and traces to improve context for anomaly detection
  and root cause analysis【677892187559889†L200-L223】.
* Use additional algorithms (e.g. One‑Class SVM, Autoencoders) and ensemble
  methods to improve detection accuracy.
* Integrate with alerting systems to trigger automated remediation scripts
  when anomalies are detected.

## References

* Selector. “AIOps in 2025: 4 Components and 4 Key Capabilities.” Defines
  AIOps as the application of AI and machine learning to automate and improve
  IT operations and highlights benefits like automated anomaly detection and
  proactive problem‑solving【677892187559889†L200-L223】.