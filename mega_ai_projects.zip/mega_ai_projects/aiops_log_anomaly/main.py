"""AIOps Log Anomaly Detection

This script implements a simple anomaly detection pipeline for IT log data.
AIOps uses machine learning and data analytics to automate tasks like event
correlation, anomaly detection and root cause analysis in IT operations【677892187559889†L200-L223】.
Here we demonstrate how to detect unusual log entries using a TF‑IDF
vectorizer and Isolation Forest algorithm from scikit‑learn.
"""
from __future__ import annotations

import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.ensemble import IsolationForest


def load_logs() -> list[str]:
    """Define a list of sample log messages.

    Returns:
        List of log strings containing both normal and anomalous entries.
    """
    return [
        "INFO 2025-12-01T12:00:00Z User login successful",
        "INFO 2025-12-01T12:01:00Z Connection established to database",
        "WARN 2025-12-01T12:02:00Z High memory usage detected",
        "INFO 2025-12-01T12:03:00Z User logout successful",
        "ERROR 2025-12-01T12:04:00Z Unexpected shutdown of service X",
        # Anomalous entries
        "ALERT 2025-12-01T12:05:00Z Unauthorized access from IP 10.0.0.1",
        "CRITICAL 2025-12-01T12:06:00Z System compromised, ransomware detected"
    ]


def detect_anomalies(logs: list[str], contamination: float = 0.2) -> pd.DataFrame:
    """Detect anomalies in a list of log messages.

    Args:
        logs: List of log strings.
        contamination: Proportion of anomalies expected in the data (between 0
            and 0.5).

    Returns:
        DataFrame with log text, anomaly score and label (1 for normal,
        -1 for anomaly).
    """
    vectorizer = TfidfVectorizer()
    X = vectorizer.fit_transform(logs)
    model = IsolationForest(contamination=contamination, random_state=42)
    model.fit(X)
    scores = model.decision_function(X)
    labels = model.predict(X)
    return pd.DataFrame({"log": logs, "score": scores, "label": labels})


def main() -> None:
    logs = load_logs()
    results = detect_anomalies(logs)
    anomalies = results[results["label"] == -1]
    print("Anomalous log entries detected:")
    for _, row in anomalies.iterrows():
        print(f"  {row['log']} (score={row['score']:.3f})")


if __name__ == "__main__":  # pragma: no cover
    main()