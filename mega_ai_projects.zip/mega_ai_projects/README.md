# Mega AI Projects

This repository contains a broad collection of AI projects spanning agentic AI, generative AI, operational tooling and deep learning architectures.  Each subfolder contains code and a README describing the aim, prerequisites, technology stack, step‑by‑step workflow and instructions for running the project.  You can explore, customise and extend these examples to suit your own needs.

## Directory Overview

| Project Directory | Description |
| --- | --- |
| `agentic_ai_projects` | Previously built agentic pipelines including the Deep Research Assistant, Customer Support Chat Agent, Real‑Time Analytics Agent and Autonomous Logistics Optimisation Platform. |
| `generative_text_agent` | A generative AI project that uses a pre‑trained language model to produce creative text based on user prompts. |
| `llmops_evaluator` | A simple LLMOps pipeline that evaluates a question‑answering model on a small dataset and computes basic metrics. |
| `aiops_log_anomaly` | An AIOps project that uses anomaly detection to find unusual log entries in system logs. |
| `mlops_model_service` | An MLOps example that trains a classification model and serves it via a REST API built with FastAPI. |
| `ann_classifier` | A feed‑forward neural network (ANN) classifier for tabular data, using the Iris dataset. |
| `cnn_image_classifier` | A convolutional neural network (CNN) for classifying handwritten digits from the MNIST dataset. |
| `rnn_sequence_model` | A character‑level recurrent neural network (RNN) that learns to generate new names. |
| `lstm_sequence_model` | A long short‑term memory (LSTM) network for time‑series forecasting on a sine wave. |
| `gru_sequence_model` | A gated recurrent unit (GRU) network for sentiment classification on short sentences. |

> **Note:** Many projects require installing additional Python packages. See each project’s README for details and instructions on how to run the code.
