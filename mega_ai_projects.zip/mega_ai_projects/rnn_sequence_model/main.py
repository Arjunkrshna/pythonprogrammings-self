"""RNN Sequence Model for Name Generation

Trains a simple character‑level RNN to generate names.  RNNs maintain a hidden
state that allows them to process sequences and predict future elements based on
past context【501703446364988†L23-L36】.  This example uses TensorFlow/Keras to build a
`SimpleRNN` model and sample new names after training.
"""
from __future__ import annotations

import numpy as np
import tensorflow as tf


def prepare_data(names: list[str]) -> tuple[np.ndarray, np.ndarray, dict[int, str], dict[str, int]]:
    """Prepare input/output sequences for training.

    Args:
        names: List of example names.

    Returns:
        Tuple of (input_sequences, target_sequences, index_to_char, char_to_index).
    """
    # Add a termination token to mark the end of each name
    names = [name.lower() + "\n" for name in names]
    vocab = sorted(set("".join(names)))
    char_to_index = {c: i for i, c in enumerate(vocab)}
    index_to_char = {i: c for c, i in char_to_index.items()}
    # Convert names to sequences of indices
    sequences = [[char_to_index[c] for c in name] for name in names]
    # Create training data: each input sequence is all characters except last; target is all characters except first
    inputs = []
    targets = []
    for seq in sequences:
        inputs.append(seq[:-1])
        targets.append(seq[1:])
    # Pad sequences to the same length
    max_len = max(len(seq) for seq in inputs)
    inputs_padded = tf.keras.preprocessing.sequence.pad_sequences(inputs, maxlen=max_len, padding="post")
    targets_padded = tf.keras.preprocessing.sequence.pad_sequences(targets, maxlen=max_len, padding="post")
    return inputs_padded, targets_padded, index_to_char, char_to_index


def build_model(vocab_size: int, embedding_dim: int = 16, rnn_units: int = 32) -> tf.keras.Model:
    """Build a character-level RNN model.

    Args:
        vocab_size: Size of the character vocabulary.
        embedding_dim: Dimension of embedding vectors.
        rnn_units: Number of hidden units in the RNN layer.

    Returns:
        Compiled Keras model.
    """
    model = tf.keras.Sequential([
        tf.keras.layers.Embedding(vocab_size, embedding_dim),
        tf.keras.layers.SimpleRNN(rnn_units, return_sequences=True),
        tf.keras.layers.Dense(vocab_size, activation="softmax"),
    ])
    model.compile(optimizer="adam", loss="sparse_categorical_crossentropy")
    return model


def sample_name(model: tf.keras.Model, start_char: str, char_to_index: dict[str, int], index_to_char: dict[int, str], max_length: int = 12) -> str:
    """Generate a name by iteratively sampling characters from the model.

    Args:
        model: Trained Keras model.
        start_char: Seed character to start the name.
        char_to_index: Mapping from characters to indices.
        index_to_char: Mapping from indices to characters.
        max_length: Maximum length of generated name.

    Returns:
        Generated name string (without termination token).
    """
    input_indices = [char_to_index[start_char]]
    name = start_char
    for _ in range(max_length):
        # Prepare input tensor (batch_size=1, time_steps=len(input_indices))
        input_array = np.array([input_indices])
        preds = model.predict(input_array, verbose=0)[0, -1]
        # Sample next index from probability distribution
        next_index = int(np.random.choice(len(preds), p=preds))
        next_char = index_to_char[next_index]
        if next_char == "\n":
            break
        name += next_char
        input_indices.append(next_index)
    return name


def main() -> None:
    # Example names dataset
    names = ["Alice", "Bob", "Carol", "Dave", "Eve", "Mallory", "Oscar", "Peggy"]
    inputs, targets, index_to_char, char_to_index = prepare_data(names)
    vocab_size = len(char_to_index)
    model = build_model(vocab_size)
    # Train the model; reshape targets to match required shape
    model.fit(inputs, targets, epochs=50, batch_size=4, verbose=0)
    # Generate some names
    print("Generated names:")
    for seed in ["a", "b", "c", "m", "o"]:
        generated = sample_name(model, seed, char_to_index, index_to_char)
        print(f"  Seed '{seed}' -> {generated}")


if __name__ == "__main__":  # pragma: no cover
    main()