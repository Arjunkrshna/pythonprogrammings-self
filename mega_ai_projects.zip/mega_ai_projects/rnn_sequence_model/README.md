# RNN Sequence Model

## Aim

This project demonstrates a **recurrent neural network (RNN)** trained on a
simple character‑level dataset to generate new names.  RNNs are deep learning
architectures designed to process sequential data by maintaining a hidden state
that captures information from previous time steps【501703446364988†L23-L36】.  Unlike
feedforward networks, RNNs can loop back on themselves, enabling them to
remember past inputs and model temporal dependencies【501703446364988†L65-L72】.

We use a small list of names as training data.  The network learns to predict
the next character in a sequence; after training, we can sample from the model
to generate new, plausible names.

## Prerequisites

* **Python 3.9+**
* [TensorFlow](https://www.tensorflow.org/) with Keras: `pip install tensorflow`.

## Tools & Libraries

| Tool | Purpose |
| --- | --- |
| `tensorflow.keras` | Provides RNN layers (`SimpleRNN`) and training utilities. |

## Workflow

1. **Prepare data** – Define a list of example names.  Create a character
   vocabulary and map each character to an integer index.  For each name,
   generate input sequences of characters and corresponding target characters.
2. **Define model** – Build a sequential model with an embedding layer,
   a `SimpleRNN` layer and a dense output layer.  The hidden state of the RNN
   captures sequential patterns【501703446364988†L23-L36】.
3. **Train** – Train the model to predict the next character given previous
   characters.
4. **Generate** – Start with a seed character and iteratively sample the next
   character from the model’s probability distribution until a termination
   condition is met (e.g. length limit or end‑of‑word symbol).

## Running the Project

```bash
# Install dependencies
pip install tensorflow

# Train the RNN and generate names
python main.py
```

## References

* Coursera. “What Is a Recurrent Neural Network?” Defines RNNs as deep learning
  algorithms that process sequences of events by remembering past inputs via a
  hidden state【501703446364988†L23-L36】 and explains that RNNs can loop back
  through layers, storing data in a hidden state to compare with new inputs【501703446364988†L65-L72】.