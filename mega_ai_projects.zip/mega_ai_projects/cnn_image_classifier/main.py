"""CNN Image Classifier

Train a convolutional neural network on the MNIST handwritten digit dataset.
CNNs learn spatial hierarchies of features via convolutional layers, pooling
layers and fully connected layers【90136356043692†L91-L116】.
"""
from __future__ import annotations

import tensorflow as tf


def build_cnn(input_shape: tuple[int, int, int], num_classes: int) -> tf.keras.Model:
    """Build a simple CNN for MNIST classification.

    Args:
        input_shape: Shape of input images (height, width, channels).
        num_classes: Number of output classes.

    Returns:
        Compiled Keras model.
    """
    model = tf.keras.Sequential([
        tf.keras.layers.Conv2D(32, (3, 3), activation='relu', input_shape=input_shape),
        tf.keras.layers.MaxPooling2D(pool_size=(2, 2)),
        tf.keras.layers.Conv2D(64, (3, 3), activation='relu'),
        tf.keras.layers.MaxPooling2D(pool_size=(2, 2)),
        tf.keras.layers.Flatten(),
        tf.keras.layers.Dense(64, activation='relu'),
        tf.keras.layers.Dense(num_classes, activation='softmax'),
    ])
    model.compile(
        optimizer='adam',
        loss='categorical_crossentropy',
        metrics=['accuracy'],
    )
    return model


def main() -> None:
    # Load MNIST data
    (x_train, y_train), (x_test, y_test) = tf.keras.datasets.mnist.load_data()
    # Reshape to (samples, 28, 28, 1)
    x_train = x_train.reshape(-1, 28, 28, 1).astype('float32') / 255.0
    x_test = x_test.reshape(-1, 28, 28, 1).astype('float32') / 255.0
    num_classes = 10
    # Convert labels to categorical
    y_train_cat = tf.keras.utils.to_categorical(y_train, num_classes)
    y_test_cat = tf.keras.utils.to_categorical(y_test, num_classes)
    model = build_cnn((28, 28, 1), num_classes)
    model.fit(x_train, y_train_cat, epochs=5, batch_size=64, validation_split=0.1, verbose=0)
    loss, acc = model.evaluate(x_test, y_test_cat, verbose=0)
    print(f"Test accuracy: {acc:.3f}")


if __name__ == "__main__":  # pragma: no cover
    main()