# CNN Image Classifier

## Aim

This project implements a **convolutional neural network (CNN)** to classify
images from the MNIST dataset.  Convolutional layers learn spatial hierarchies
of features (e.g. edges, textures and shapes) and are the foundation of modern
computer vision systems【90136356043692†L86-L100】.  A typical CNN consists of
convolutional layers, pooling layers and fully connected layers to produce
predictions【90136356043692†L91-L116】.

The MNIST dataset contains 70 000 images of handwritten digits (0–9) in
grayscale.  The goal is to train a model that can recognise and classify these
digits with high accuracy.

## Prerequisites

* **Python 3.9+**
* [TensorFlow](https://www.tensorflow.org/) with Keras: `pip install tensorflow`.

## Tools & Libraries

| Tool | Purpose |
| --- | --- |
| `tensorflow.keras` | Provides layers and training utilities for building CNNs. |

## Workflow

1. **Load data** – Use Keras to download the MNIST dataset and split into
   training and test sets.  Reshape and normalise pixel values to the range
   `[0, 1]`.
2. **Define model** – Build a sequential CNN with convolutional and pooling
   layers to extract features, followed by a flattening layer and fully
   connected layers for classification【90136356043692†L91-L116】.
3. **Compile** – Choose an appropriate loss function (categorical
   cross‑entropy), optimizer (e.g. Adam) and metrics.
4. **Train** – Train the model on the training set for a number of epochs.
5. **Evaluate** – Evaluate the model on the test set and report accuracy.

## Running the Project

```bash
# Install dependencies
pip install tensorflow

# Train and evaluate the CNN classifier
python main.py
```

## References

* GeeksforGeeks. “Convolutional Neural Network (CNN) in Deep Learning.”
  Explains that CNNs process data with a grid‑like topology (such as images) and
  describes key components: convolutional layers, pooling layers, activation
  functions and fully connected layers【90136356043692†L86-L116】.