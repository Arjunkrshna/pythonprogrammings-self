"""
Entry point for the Real‑Time Analytics Agent.

Given a stock ticker, this script concurrently retrieves price data from
yfinance and the latest headlines from a news API, performs sentiment
analysis on the headlines and synthesises simple insights.  The design
mimics a multi‑tool agentic application, where different tools (data
retrieval, sentiment analysis, reasoning) are orchestrated together
【982287278172708†L218-L326】.

Usage:
    python main.py --ticker AAPL --days 5
"""

from __future__ import annotations

import argparse
import asyncio
import datetime as dt
import os
from typing import List, Dict, Any

import aiohttp
import numpy as np  # type: ignore
import pandas as pd  # type: ignore
import yfinance as yf  # type: ignore

try:
    from transformers import pipeline  # type: ignore
except ImportError:
    pipeline = None


async def fetch_stock_prices(ticker: str, days: int) -> pd.DataFrame:
    """Fetch historical stock data for the past `days` days."""
    end = dt.datetime.utcnow()
    start = end - dt.timedelta(days=days * 2)  # fetch a bit more to ensure trading days
    data = yf.download(ticker, start=start.date(), end=end.date(), progress=False)
    return data.tail(days)


async def fetch_news(ticker: str, api_key: str) -> List[Dict[str, str]]:
    """Fetch recent news headlines related to the ticker using NewsAPI."""
    # We'll use NewsAPI's /v2/everything endpoint
    url = "https://newsapi.org/v2/everything"
    params = {
        "q": ticker,
        "sortBy": "publishedAt",
        "pageSize": 5,
        "language": "en",
        "apiKey": api_key,
    }
    async with aiohttp.ClientSession() as session:
        async with session.get(url, params=params, timeout=30) as resp:
            resp.raise_for_status()
            data = await resp.json()
    articles = []
    for item in data.get("articles", [])[:5]:
        articles.append(
            {
                "title": item.get("title", ""),
                "description": item.get("description", ""),
                "url": item.get("url", ""),
            }
        )
    return articles


def analyse_sentiment(texts: List[str]) -> List[Dict[str, Any]]:
    """Perform sentiment analysis on a list of texts.

    Uses a DistilBERT sentiment model.  If transformers is not installed,
    returns neutral sentiment for each entry.
    """
    if pipeline is None:
        return [
            {"label": "neutral", "score": 0.0}
            for _ in texts
        ]
    sentiment_model = pipeline(
        "sentiment-analysis", model="distilbert-base-uncased-finetuned-sst-2-english"
    )
    results = sentiment_model(texts)
    return results


def synthesize_insights(prices: pd.DataFrame, sentiments: List[Dict[str, Any]]) -> str:
    """Combine price trend and sentiment into a simple narrative."""
    # Price change
    if prices.empty:
        price_summary = "No price data available."
    else:
        pct_change = (prices["Close"].iloc[-1] - prices["Close"].iloc[0]) / prices["Close"].iloc[0] * 100
        price_summary = f"Price changed by {pct_change:.2f}% over the selected period."
    # Sentiment summary
    if not sentiments:
        sentiment_summary = "No news available."
    else:
        # Map labels to scores (+1, -1)
        scores = []
        for s in sentiments:
            label = s["label"].lower()
            score = s["score"]
            val = 0.0
            if label == "positive":
                val = score
            elif label == "negative":
                val = -score
            scores.append(val)
        avg_score = np.mean(scores)
        if avg_score > 0.1:
            sentiment_summary = f"News sentiment is mostly positive (average {avg_score:.2f})."
        elif avg_score < -0.1:
            sentiment_summary = f"News sentiment is mostly negative (average {avg_score:.2f})."
        else:
            sentiment_summary = f"News sentiment is neutral (average {avg_score:.2f})."
    return price_summary + " " + sentiment_summary


async def run_agent(ticker: str, days: int, api_key: str) -> None:
    price_task = asyncio.create_task(fetch_stock_prices(ticker, days))
    news_task = asyncio.create_task(fetch_news(ticker, api_key))
    prices, articles = await asyncio.gather(price_task, news_task)
    headlines = [a["title"] or a["description"] for a in articles]
    sentiments = analyse_sentiment(headlines)
    insight = synthesize_insights(prices, sentiments)
    print(f"\n=== {ticker.upper()} Analysis ===\n")
    if not prices.empty:
        print(prices[["Close"]].tail())
    print("\nTop Headlines and Sentiment:")
    for art, sent in zip(articles, sentiments):
        print(f"- {art['title']} -> {sent['label']} ({sent['score']:.2f})")
    print("\nInsights:")
    print(insight)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run the Real-Time Analytics Agent.")
    parser.add_argument("--ticker", required=True, help="Stock ticker symbol")
    parser.add_argument(
        "--days", type=int, default=5, help="Number of days of price history to analyse"
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    api_key = os.environ.get("NEWS_API_KEY")
    if not api_key:
        raise EnvironmentError(
            "A NEWS_API_KEY environment variable is required to fetch headlines."
        )
    asyncio.run(run_agent(args.ticker, args.days, api_key))


if __name__ == "__main__":
    main()
