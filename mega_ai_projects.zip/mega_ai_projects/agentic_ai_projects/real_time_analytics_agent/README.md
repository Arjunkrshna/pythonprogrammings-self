# Real‑Time Analytics Agent

This project builds a **real‑time analytics assistant** that monitors financial data, fetches relevant news, performs sentiment analysis and provides insights to the user.  It draws inspiration from agentic applications built with LangGraph, where an agent chooses between web search and code execution tools to answer questions【982287278172708†L218-L326】.  Our implementation uses open‑source libraries and is suitable for learning how to combine multiple tools in a single workflow.

## Aim

Demonstrate a multi‑tool agent that can:

1. **Retrieve live market data:** Use `yfinance` to download recent price history for a given stock ticker.
2. **Gather recent news:** Query a news API (e.g., NewsAPI or Tavily) for headlines related to the stock.
3. **Perform sentiment analysis:** Analyse the sentiment of each headline using a transformer model (`distilbert-base-uncased-finetuned-sst-2-english`).
4. **Generate insights:** Summarise the price trend and average sentiment to inform the user whether the short‑term outlook appears positive, negative or neutral.
5. **Use asynchronous tasks:** Fetch data and run analysis concurrently to reduce latency.

## Prerequisites

* **Python ≥ 3.10**
* Internet access to download market data and news
* API key for a news service (`NEWS_API_KEY` environment variable)

### Dependencies

Install required packages:

```bash
pip install yfinance transformers==4.40.0 torch pandas aiohttp numpy
```

If you plan to use OpenAI or another LLM service for summarisation, install the appropriate library and set the environment variable.

## How It Works

1. **Data retrieval:** The agent asynchronously downloads stock price data via `yfinance` and queries the news API for recent headlines.
2. **Sentiment analysis:** Each headline is passed through a sentiment analysis pipeline (a transformer model) to classify it as positive, negative or neutral.  The pipeline returns both the sentiment label and a confidence score.
3. **Insight generation:** The agent computes simple metrics such as percentage change over the past week and the average sentiment score.  It then generates a textual insight (e.g., “Stock is up 3 % over the last 5 days; news sentiment is mostly positive”).
4. **Presentation:** The results are printed to the console.  You can extend this project with a web dashboard or alerts.

## Running the Script

1. Export your news API key: `export NEWS_API_KEY=your_api_key`.
2. Run the agent with a ticker symbol:

```bash
python main.py --ticker AAPL --days 5
```

The agent will display recent price changes, top headlines with sentiment scores and an overall assessment.

## Extending the Project

* Use a vector database and LLM (via LangGraph) to answer arbitrary finance questions, similar to LangGraph’s real‑time analytics example【982287278172708†L218-L326】.
* Integrate additional data sources (e.g., social media, on‑chain data) and tools (e.g., Python REPL, chart generation) to provide richer insights.

## Citation

Our design mirrors the LangGraph tutorial, where a multi‑tool agent uses web search and a Python REPL to answer questions【982287278172708†L218-L326】.  In our case, the agent chooses between data retrieval and sentiment analysis tools to produce insights.
