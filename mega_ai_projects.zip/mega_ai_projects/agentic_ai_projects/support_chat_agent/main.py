"""
Entry point for the Customer Support Chat Agent.

This script loads a FAQ knowledge base, builds a FAISS index for retrieval,
and launches a simple chat loop where the assistant answers questions.  When
an OpenAI API key is provided, it uses GPT‑3.5‑turbo to generate polite,
contextual responses; otherwise it returns the closest FAQ answer directly.

Usage:
    python main.py --faq-file faq.json --threshold 0.75

Type 'exit' to quit the chat.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from typing import List, Tuple

import numpy as np  # type: ignore
import faiss  # type: ignore

try:
    from sentence_transformers import SentenceTransformer  # type: ignore
except ImportError:
    raise ImportError(
        "sentence-transformers is required; install via `pip install sentence-transformers`"
    )

try:
    import openai  # type: ignore
except ImportError:
    openai = None


def load_faq(path: str) -> Tuple[List[str], List[str]]:
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    questions, answers = [], []
    for item in data:
        questions.append(item["question"])
        answers.append(item["answer"])
    return questions, answers


def build_index(questions: List[str]) -> Tuple[faiss.Index, np.ndarray, SentenceTransformer]:
    model = SentenceTransformer("all-MiniLM-L6-v2")
    embeddings = model.encode(questions, normalize_embeddings=True)
    # Use inner product on normalised vectors ≈ cosine similarity
    dim = embeddings.shape[1]
    index = faiss.IndexFlatIP(dim)
    index.add(embeddings.astype(np.float32))
    return index, embeddings, model


def retrieve_answer(
    query: str, index: faiss.Index, embeddings: np.ndarray, model: SentenceTransformer, answers: List[str],
    threshold: float = 0.75,
) -> Tuple[str, float]:
    query_emb = model.encode([query], normalize_embeddings=True).astype(np.float32)
    scores, indices = index.search(query_emb, 1)
    score = float(scores[0][0])
    idx = int(indices[0][0])
    if score < threshold:
        return "", score
    return answers[idx], score


def generate_response(prompt: str, context: str = "") -> str:
    """Use OpenAI to generate a response.  If unavailable, return context."""
    if openai is None or not os.environ.get("OPENAI_API_KEY"):
        return context if context else "I'm sorry, I don't have enough information to answer that."
    openai.api_key = os.environ["OPENAI_API_KEY"]
    messages = []
    system_message = (
        "You are a helpful customer support assistant."
        " Answer the user's question using the provided context when available."
    )
    messages.append({"role": "system", "content": system_message})
    if context:
        messages.append(
            {
                "role": "system",
                "content": f"Context: {context}",
            }
        )
    messages.append({"role": "user", "content": prompt})
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=messages,
        temperature=0.3,
        max_tokens=200,
    )
    return response.choices[0].message.content.strip()


def chat_loop(index: faiss.Index, embeddings: np.ndarray, model: SentenceTransformer, answers: List[str], threshold: float) -> None:
    print("\nCustomer Support Chat Agent. Type 'exit' to quit.\n")
    while True:
        try:
            query = input("You: ").strip()
        except EOFError:
            break
        if not query or query.lower() in {"exit", "quit"}:
            print("Goodbye!")
            break
        context, score = retrieve_answer(query, index, embeddings, model, answers, threshold)
        if context:
            response = generate_response(query, context)
        else:
            response = generate_response(query, context="")
        print(f"Agent: {response}\n")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run the Customer Support Chat Agent.")
    parser.add_argument("--faq-file", type=str, default="faq.json", help="Path to the FAQ JSON file")
    parser.add_argument(
        "--threshold", type=float, default=0.75, help="Similarity threshold for using a FAQ answer"
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    questions, answers = load_faq(args.faq_file)
    index, embeddings, model = build_index(questions)
    chat_loop(index, embeddings, model, answers, threshold=args.threshold)


if __name__ == "__main__":
    main()
