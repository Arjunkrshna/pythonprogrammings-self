# Customer Support Chat Agent

This project demonstrates how to build a **retrieval‑augmented chat assistant** that answers user questions based on a local knowledge base (FAQ) and, when necessary, calls a language model to craft a helpful response.  The design echoes Haystack’s approach to RAG and agentic pipelines, where the system first checks a private knowledge base and only falls back to web search when the answer is not available【870453656182262†L342-L452】.

## Aim

Build an end‑to‑end chatbot that:

1. **Indexes a FAQ dataset:** Preprocess a set of question–answer pairs, compute embeddings and store them in a FAISS vector database for efficient retrieval.
2. **Retrieves relevant answers:** When a user asks a question, embed the query and find the nearest neighbour in the FAQ index.
3. **Generates responses:** Use the retrieved answer as context for a language model (e.g., OpenAI GPT‑3.5‑turbo) to produce a conversational reply.  If no answer is sufficiently similar, the model can still answer generatively.
4. **Provides a simple chat interface:** A command‑line loop that accepts user input and returns the assistant’s response.

## Prerequisites

* **Python ≥ 3.10**
* A knowledge base file in JSON format (`faq.json` is provided with sample entries).
* Optional: An OpenAI API key (`OPENAI_API_KEY`) or another LLM API for generating responses.

### Dependencies

Install the following packages:

```bash
pip install numpy faiss-cpu sentence-transformers openai
```

The `faiss-cpu` package provides vector similarity search on CPUs.  You may use `faiss-gpu` if you have a compatible GPU.

## How It Works

1. **Data loading:** The script loads question–answer pairs from `faq.json`.
2. **Embedding computation:** We use the [Sentence-Transformers](https://www.sbert.net/) model `all-MiniLM-L6-v2` to embed each question into a dense vector.
3. **Index construction:** FAISS is used to build an index over the embeddings.  Cosine similarity (implemented as inner product after normalisation) is used to measure similarity.
4. **Answer retrieval:** For each user query, we embed the query and retrieve the nearest FAQ question.  If the similarity exceeds a threshold (configurable), we treat the corresponding answer as context for the language model.  Otherwise, the language model receives only the user question.
5. **Response generation:** The final answer is generated via the OpenAI API (or stubbed if no key is provided).  This agentic design ensures that the assistant leverages existing knowledge before resorting to generative output.

## Running the Script

1. Place your FAQ data in `faq.json` following the provided format: a list of objects with `question` and `answer` fields.
2. Export your OpenAI API key if available: `export OPENAI_API_KEY=your_key`.
3. Run the assistant:

```bash
python main.py
```

Type your questions at the prompt; type `exit` to quit.

## Extending the Project

* Replace the JSON FAQ with a knowledge base of product manuals, internal wiki pages or other documents.
* Integrate additional tools such as web search or database queries.  Haystack’s agentic workflows show how to combine RAG with live information retrieval【870453656182262†L342-L452】.
* Build a web UI using Flask or FastAPI for easier interaction.

## Citation

This project takes inspiration from agentic RAG pipelines where systems first consult a private knowledge base and only resort to external search when necessary【870453656182262†L442-L452】.  See the Haystack tutorial for details on building such agents【870453656182262†L342-L452】.
