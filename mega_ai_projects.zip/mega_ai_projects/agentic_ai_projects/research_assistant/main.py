"""
Entry point for the Deep Research Assistant.

This script orchestrates the query generation, web search, article
extraction, summarisation and report composition.  It is designed to run
asynchronously to maximise throughput when fetching multiple web pages.

Usage:
    python main.py --topic "Quantum Computing" --max-results 3 --max-pages 2

See the README.md for details on prerequisites and configuration.
"""

from __future__ import annotations

import argparse
import asyncio
import os
from typing import List, Dict, Any

from agents import SearchAgent, ArticleExtractor, SummariserAgent, ReportComposer, generate_queries


async def process_topic(
    topic: str, max_results: int = 5, max_pages: int = 3
) -> str:
    """Run the research pipeline for a given topic and return the report.

    Args:
        topic: The research topic.
        max_results: Number of search results per query.
        max_pages: Maximum number of pages to summarise across all queries.

    Returns:
        The report as a markdown string.
    """
    queries = generate_queries(topic)
    search_agent = SearchAgent()
    extractor = ArticleExtractor()
    summariser = SummariserAgent()
    composer = ReportComposer()

    collected: List[Dict[str, Any]] = []
    pages_processed = 0
    for query in queries:
        results = await search_agent.search(query, num_results=max_results)
        for res in results:
            if pages_processed >= max_pages:
                break
            url = res["url"]
            title = res["title"] or query
            text = await extractor.fetch(url)
            if not text:
                continue
            summary = await summariser.summarise(text)
            collected.append({"title": title, "url": url, "summary": summary})
            pages_processed += 1
        if pages_processed >= max_pages:
            break

    report = composer.compose(topic, collected)
    return report


def save_report(report: str, filename: str = "report.md") -> None:
    with open(filename, "w", encoding="utf-8") as f:
        f.write(report)
    print(f"Report saved to {filename}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run the Deep Research Assistant.")
    parser.add_argument("--topic", required=True, help="Topic to research")
    parser.add_argument("--max-results", type=int, default=5, help="Results per query")
    parser.add_argument("--max-pages", type=int, default=3, help="Maximum pages to process")
    parser.add_argument(
        "--output", type=str, default="report.md", help="Output markdown file name"
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    try:
        report = asyncio.run(
            process_topic(args.topic, max_results=args.max_results, max_pages=args.max_pages)
        )
        save_report(report, args.output)
    except Exception as e:
        print(f"Error: {e}")


if __name__ == "__main__":
    main()
