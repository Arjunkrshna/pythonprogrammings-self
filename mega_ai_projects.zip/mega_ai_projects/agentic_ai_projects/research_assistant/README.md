# Deep Research Assistant

This project implements a **Deep Research Assistant** – an agentic pipeline that takes a user‑specified topic, automatically formulates search queries, retrieves and summarises relevant web content and produces a polished research report.  The design is inspired by real‑world agentic systems such as the Jan‑v1 assistant, which performs dynamic web search, summarisation and structured report generation【383478907666697†L278-L289】.  While our implementation uses open‑source tools and requires API keys for web search, the overall workflow reflects how modern research automation works.

## Aim

Provide an end‑to‑end example of an AI research assistant that:

1. **Generates intelligent search queries:** Starting from a topic, the agent proposes a list of sub‑topics or questions to guide web search.
2. **Performs asynchronous web search and scraping:** For each query, the agent calls a search API and retrieves the top web pages.  As in the Jan‑v1 demo, it uses multiple queries and asynchronous calls to gather a broad set of sources【383478907666697†L278-L289】.
3. **Summarises documents:** Each article or page is summarised using a transformer‑based summariser so that the agent works efficiently with long texts.
4. **Composes a structured report:** The agent organises the summarised information into sections (introduction, main points, conclusion) and produces a final report with citations and references.

## Prerequisites

* **Python ≥ 3.10**
* Internet connection for web search and model downloads
* API key for a search service such as [Serper](https://serper.dev/) or [Tavily](https://app.tavily.com/) – the code expects the key in the `SERPER_API_KEY` environment variable.
* Optional: [OpenAI](https://openai.com) API key if you prefer to use GPT‑3.5/4 for summarisation instead of the bundled transformer model.

### Dependencies

Install the dependencies via pip:

```bash
pip install aiohttp beautifulsoup4 transformers==4.40.0 tqdm
```

If you plan to use OpenAI models, also install `openai`:

```bash
pip install openai
```

## How It Works

1. **Query generation:** Given a topic, the script generates a list of search queries.  This can be as simple as appending phrases like “overview,” “recent developments” and “controversies” or as sophisticated as using an LLM to propose sub‑topics.
2. **Asynchronous search:** For each query, we call the Serper search API (or another service).  As recommended in the Jan‑v1 tutorial, asynchronous calls speed up fetching multiple pages【383478907666697†L278-L289】.
3. **Content extraction:** We download each result’s page and extract the main text using Beautiful Soup.  Only a limited number of pages are fetched to stay within API usage limits.
4. **Summarisation:** Texts are summarised with a transformer summariser (`bart-base` by default).  If an OpenAI key is available, you can instead call `gpt-3.5-turbo` for higher‑quality summaries.
5. **Report composition:** Summaries are combined into a final report with sections.  The agent creates a markdown report and lists the URLs used as references.

## Running the Script

1. Export your search API key: `export SERPER_API_KEY=your_key_here`.
2. Optionally export `OPENAI_API_KEY` for LLM summarisation.
3. Run the assistant:

```bash
python main.py --topic "Impacts of Climate Change on Agriculture" --max-results 3 --max-pages 2
```

This generates a `report.md` file in the current directory.  You can adjust `--max-results` (number of search results per query) and `--max-pages` (number of pages to process) based on your API quota.

## Files

* `main.py` – entry point that orchestrates query generation, search, summarisation and report composition.
* `agents.py` – contains helper classes for web search, summarisation and report composition.

## Extending the Project

* Replace the simple query generator with an LLM call to produce tailored search queries.
* Add citation extraction to link specific facts back to their sources.
* Integrate more advanced agentic frameworks such as LangChain or Haystack to manage tool invocation.

## Citation

This project draws inspiration from the Deep Research Assistant described in DataCamp’s article, where Jan‑v1 performs local inference, asynchronous web search and structured report generation【383478907666697†L278-L289】.  You can learn more about Jan‑v1’s agentic architecture and local deployment in the accompanying Jan‑v1 tutorial【673928626846456†L97-L115】.
