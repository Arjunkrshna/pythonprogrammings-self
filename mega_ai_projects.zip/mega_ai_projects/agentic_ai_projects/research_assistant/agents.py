"""
Helper classes for the Deep Research Assistant.

This module defines agents that handle web search, article extraction,
summarisation and report composition.  Each agent encapsulates a part of the
pipeline so that the overall system can be extended or replaced easily.

The design follows the idea that an agentic system should break a complex
task into smaller sub‑tasks and delegate each to specialised components.
"""

from __future__ import annotations

import asyncio
import os
import re
from typing import List, Dict, Optional, Any

import aiohttp
from bs4 import BeautifulSoup
from tqdm import tqdm

try:
    from transformers import pipeline
except ImportError:
    pipeline = None  # type: ignore

try:
    import openai  # type: ignore
except ImportError:
    openai = None  # type: ignore


class SearchAgent:
    """Agent responsible for performing web searches via the Serper API.

    The Serper API is a wrapper around Google search.  You must set
    ``SERPER_API_KEY`` in your environment for this agent to work.  See
    https://serper.dev/ for details.  If you prefer another service,
    modify ``_search()`` accordingly.
    """

    def __init__(self, api_key: Optional[str] = None) -> None:
        self.api_key = api_key or os.environ.get("SERPER_API_KEY")
        if not self.api_key:
            raise ValueError(
                "A SERPER_API_KEY environment variable or argument is required."
            )

    async def search(self, query: str, num_results: int = 5) -> List[Dict[str, str]]:
        """Perform a search and return a list of results.

        Args:
            query: The search query.
            num_results: Number of results to return.

        Returns:
            A list of dicts with keys 'title', 'url' and 'snippet'.
        """
        url = "https://google.serper.dev/search"
        payload = {"q": query, "num": num_results}
        headers = {"X-API-KEY": self.api_key, "Content-Type": "application/json"}
        async with aiohttp.ClientSession() as session:
            async with session.post(url, json=payload, headers=headers, timeout=30) as resp:
                resp.raise_for_status()
                data = await resp.json()
        results: List[Dict[str, Any]] = []
        for item in data.get("organic", [])[:num_results]:
            results.append(
                {
                    "title": item.get("title", ""),
                    "url": item.get("link", ""),
                    "snippet": item.get("snippet", ""),
                }
            )
        return results


class ArticleExtractor:
    """Agent responsible for downloading and cleaning webpage content."""

    async def fetch(self, url: str) -> str:
        async with aiohttp.ClientSession() as session:
            try:
                async with session.get(url, timeout=30) as resp:
                    text = await resp.text()
            except Exception:
                return ""
        return self._extract_text(text)

    def _extract_text(self, html: str) -> str:
        soup = BeautifulSoup(html, "html.parser")
        # Remove script/style
        for tag in soup(["script", "style", "noscript"]):
            tag.extract()
        text = soup.get_text(separator=" ")
        # Collapse whitespace
        text = re.sub(r"\s+", " ", text)
        return text.strip()


class SummariserAgent:
    """Agent responsible for summarising long texts using a model.

    If the ``OPENAI_API_KEY`` is set in your environment and the ``openai``
    package is installed, this agent will use OpenAI’s API for summarisation.
    Otherwise it will fall back to a Hugging Face transformer summariser.
    """

    def __init__(self) -> None:
        self.use_openai = openai is not None and os.environ.get("OPENAI_API_KEY")
        self.summariser = None  # lazy initialisation

    def _load_model(self):
        if not self.summariser and not self.use_openai:
            if pipeline is None:
                raise ImportError(
                    "transformers is not installed; install it or set OPENAI_API_KEY"
                )
            # Use BART base for summarisation; adjust model or parameters as needed
            self.summariser = pipeline(
                "summarization", model="facebook/bart-base", tokenizer="facebook/bart-base"
            )

    async def summarise(self, text: str, max_chars: int = 2000) -> str:
        """Summarise a large text.

        The input is truncated to ``max_chars`` to control costs when using
        OpenAI.
        """
        text = text[:max_chars]
        if self.use_openai:
            openai.api_key = os.environ["OPENAI_API_KEY"]
            response = await openai.ChatCompletion.acreate(
                model="gpt-3.5-turbo",
                messages=[{"role": "user", "content": f"Summarise the following text succinctly:\n{text}"}],
                temperature=0.2,
                max_tokens=300,
            )
            return response.choices[0].message.content.strip()
        else:
            self._load_model()
            # The HF pipeline is synchronous; wrap in a thread to avoid blocking the event loop
            loop = asyncio.get_event_loop()
            return await loop.run_in_executor(
                None,
                lambda: self.summariser(text, max_length=120, min_length=30, do_sample=False)[0][
                    "summary_text"
                ],
            )


class ReportComposer:
    """Agent responsible for composing the final report from summaries."""

    def compose(self, topic: str, summaries: List[Dict[str, Any]]) -> str:
        lines = []
        lines.append(f"# {topic}\n")
        lines.append("## Introduction\n")
        lines.append(
            f"This report provides an overview of **{topic}** based on web sources.\n\n"
        )
        lines.append("## Findings\n")
        for i, item in enumerate(summaries, start=1):
            lines.append(f"### {i}. {item['title']}\n")
            lines.append(item["summary"] + "\n")
            lines.append(f"*Source:* {item['url']}\n\n")
        lines.append("## Conclusion\n")
        lines.append(
            "The above sources were synthesised to provide a concise summary of the topic."
        )
        return "\n".join(lines)


def generate_queries(topic: str) -> List[str]:
    """Generate a list of search queries based on the topic.

    This simple implementation appends a few common research modifiers.  You
    can replace this logic with an LLM call to produce more specific queries.
    """
    return [
        topic,
        f"{topic} overview",
        f"{topic} recent developments",
        f"{topic} controversies",
    ]
