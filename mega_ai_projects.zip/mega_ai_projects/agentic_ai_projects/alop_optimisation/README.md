# Autonomous Logistics Optimisation Platform (ALOP)

This project presents an **Autonomous Logistics Optimisation Platform** that uses classical optimisation techniques to solve a vehicle routing problem (VRP).  The VRP involves determining optimal routes for a fleet of vehicles to visit a set of locations while minimising the longest route or total travel distance.  As Google’s OR‑Tools documentation explains, the VRP seeks to minimise the length of the longest route for efficient delivery completion【482107401486142†L152-L164】, and OR‑Tools provides a flexible framework for modelling such problems【482107401486142†L152-L160】.

## Aim

Demonstrate how to build an end‑to‑end logistics optimisation pipeline by:

1. **Creating a distance matrix:** Generate random coordinates for delivery points and compute pairwise distances.
2. **Formulating the VRP:** Use OR‑Tools to create a routing model specifying the number of vehicles and the depot.
3. **Solving the optimisation problem:** Configure search parameters and find routes that minimise the total distance (or the longest route).
4. **Interpreting results:** Output the route for each vehicle and the total distance travelled.
5. **Explaining the agentic connection:** Discuss how this classical optimisation module can be integrated into an agentic system that, for example, uses an LLM to decide on constraints or interpret results.

## Prerequisites

* **Python ≥ 3.10**
* `ortools` Python library

Install dependencies:

```bash
pip install ortools numpy
```

## How It Works

1. **Data generation:** The script randomly samples coordinates in a plane to represent delivery locations.  The depot (starting point) is set to index 0.
2. **Distance computation:** A Euclidean distance matrix is computed between all points.  OR‑Tools uses this matrix to calculate route costs.
3. **Routing model:** Using `pywrapcp.RoutingIndexManager` and `pywrapcp.RoutingModel`, we define the number of vehicles and the depot.  OR‑Tools uses constraints and search parameters to explore feasible routes.
4. **Objective:** Our solver minimises the total distance travelled by all vehicles.  This aligns with VRP objectives described in the OR‑Tools guide【482107401486142†L170-L182】.
5. **Solution output:** Once solved, the script prints each vehicle’s route and the distance covered.

## Running the Script

You can execute the optimiser as follows:

```bash
python main.py --num-locations 10 --num-vehicles 3
```

This will generate 10 locations (including the depot) and solve the VRP with 3 vehicles.  Adjust the parameters to experiment with different problem sizes.

## Integration with Agentic Systems

Although this project uses deterministic optimisation rather than language models, it illustrates how an AI agent might incorporate classical solvers.  For example, an agentic assistant could collect delivery requirements from a user, call this optimisation module to compute routes and then present the solution in natural language.  The agent might also refine constraints (e.g., time windows or vehicle capacities) based on user input and re‑solve the problem.

## Citation

The VRP is a well‑studied problem where the goal is to determine optimal routes for multiple vehicles【482107401486142†L170-L182】.  OR‑Tools provides a framework for building and solving such problems using distance matrices and constraints【482107401486142†L152-L160】.  This project uses OR‑Tools’ Python API to implement an example VRP.
