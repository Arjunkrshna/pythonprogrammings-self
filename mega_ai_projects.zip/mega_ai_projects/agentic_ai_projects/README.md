# Agentic AI Projects Collection

This repository contains multiple end‑to‑end AI projects that demonstrate how to build **agentic** applications and an optimisation system from scratch.  Each project comes with a clear objective, prerequisites, technology stack and step‑by‑step instructions, enabling you to recreate, customise and extend the work on your own machine.

## Projects Included

| Project Name | Description |
| --- | --- |
| [Deep Research Assistant](research_assistant/README.md) | An agentic pipeline that takes a topic, generates smart search queries, retrieves web documents, summarises key information and composes a structured research report. |
| [Customer Support Chat Agent](support_chat_agent/README.md) | A retrieval‑augmented chat assistant that answers user questions using a local FAQ knowledge base and, when required, invokes a large language model to generate responses. |
| [Real‑Time Analytics Agent](real_time_analytics_agent/README.md) | A multi‑tool agent that monitors financial markets, fetches latest news, analyses sentiment and produces insights using a graph‑based agentic framework. |
| [Autonomous Logistics Optimisation Platform (ALOP)](alop_optimisation/README.md) | A logistics optimisation project that uses Google OR‑Tools to solve a vehicle routing problem (VRP) and illustrates how agentic reasoning can be combined with classical optimisation. |

> **Note:** These projects are intentionally modular. Feel free to explore individual subfolders to understand each pipeline in depth.
