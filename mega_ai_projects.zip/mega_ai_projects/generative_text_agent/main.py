"""Generative Text Agent

This script provides a simple interface for generating text using a pre‑trained
language model from the Hugging Face Transformers library.  Generative AI works
by learning patterns from large corpora to produce new content such as text,
images or music【453969972241731†L322-L347】.  The goal of this script is to
demonstrate how to load a model, generate text based on a user prompt and
display the result.

Usage:
    python main.py --prompt "The future of AI" --model distilgpt2 --max_length 100

Dependencies:
    pip install transformers torch
"""
from __future__ import annotations

import argparse
import sys
from typing import Optional

try:
    from transformers import pipeline
except ImportError as e:  # pragma: no cover
    raise ImportError("Please install the transformers package: pip install transformers") from e


def generate_text(prompt: str, model_name: str = "distilgpt2", max_length: int = 50) -> str:
    """Generate text from a given prompt using a specified model.

    Args:
        prompt: Initial text prompt to seed the generator.
        model_name: Name of the pre‑trained model to use (defaults to distilgpt2).
        max_length: Maximum length of the generated sequence including the prompt.

    Returns:
        Generated text string.
    """
    text_generator = pipeline("text-generation", model=model_name)
    # Generate with do_sample=True to allow variation; temperature can be tuned
    outputs = text_generator(prompt, max_length=max_length, num_return_sequences=1, do_sample=True)
    return outputs[0]["generated_text"]


def parse_args(argv: Optional[list[str]] = None) -> argparse.Namespace:
    """Parse command line arguments.

    Args:
        argv: List of arguments passed from the command line.

    Returns:
        Parsed arguments namespace.
    """
    parser = argparse.ArgumentParser(description="Generate text using a pre‑trained language model.")
    parser.add_argument(
        "--prompt",
        type=str,
        default="Hello, world",
        help="Prompt to seed the text generation.",
    )
    parser.add_argument(
        "--model",
        type=str,
        default="distilgpt2",
        help="Name of the Hugging Face model to use (e.g. distilgpt2, gpt2).",
    )
    parser.add_argument(
        "--max_length",
        type=int,
        default=50,
        help="Maximum length of the generated text including the prompt.",
    )
    return parser.parse_args(argv)


def main(argv: Optional[list[str]] = None) -> int:
    args = parse_args(argv)
    try:
        generated = generate_text(args.prompt, model_name=args.model, max_length=args.max_length)
    except Exception as exc:  # pragma: no cover
        print(f"Error generating text: {exc}", file=sys.stderr)
        return 1
    print("\nGenerated Text:\n")
    print(generated)
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())