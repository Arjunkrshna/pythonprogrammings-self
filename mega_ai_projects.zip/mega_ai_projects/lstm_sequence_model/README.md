# LSTM Sequence Model

## Aim

This project uses a **long short‑term memory (LSTM)** network to perform
time‑series forecasting on a synthetic sine wave.  LSTM networks are a type of
recurrent neural network that addresses the vanishing gradient problem by
maintaining a more powerful working memory【501703446364988†L147-L152】.  This allows
them to learn long‑term dependencies in sequential data.

The model learns to predict the next value in a sine wave given a sequence of
previous values.  After training we can forecast future points and compare
predictions to the ground truth.

## Prerequisites

* **Python 3.9+**
* [TensorFlow](https://www.tensorflow.org/): `pip install tensorflow`.

## Tools & Libraries

| Tool | Purpose |
| --- | --- |
| `tensorflow.keras` | Provides LSTM layers and training utilities. |

## Workflow

1. **Generate data** – Create a sine wave and normalize it.  Use a sliding
   window to prepare sequences of length `n_steps` and their corresponding
   targets.
2. **Define model** – Build a sequential model with an `LSTM` layer and a
   dense output layer to predict the next value.  LSTMs maintain cell and
   hidden states that store information across time steps【501703446364988†L147-L152】.
3. **Train** – Train the model on the generated sequences using mean squared
   error loss.
4. **Forecast** – Use the trained model to generate future values by feeding
   predicted outputs back as inputs.

## Running the Project

```bash
# Install dependencies
pip install tensorflow

# Train the LSTM model and generate a forecast
python main.py
```

## References

* Coursera. “What Is a Recurrent Neural Network?”.  Discusses how LSTMs help
  overcome vanishing/exploding gradients and provide a more powerful working
  memory for long‑term patterns【501703446364988†L147-L152】.