"""LSTM Sequence Model for Sine Wave Forecasting

This script trains an LSTM network to predict the next value in a sine wave.
LSTMs are designed to remember long‑term dependencies by maintaining an
internal state, overcoming the limitations of vanilla RNNs【501703446364988†L147-L152】.
"""
from __future__ import annotations

import numpy as np
import tensorflow as tf


def generate_sine_wave(num_points: int = 500) -> np.ndarray:
    """Generate a sine wave with the specified number of points.

    Args:
        num_points: Number of points in the sine wave.

    Returns:
        Array of sine values.
    """
    x = np.linspace(0, 4 * np.pi, num_points)
    return np.sin(x)


def prepare_sequences(data: np.ndarray, n_steps: int = 20) -> tuple[np.ndarray, np.ndarray]:
    """Prepare sequences and targets for training.

    Args:
        data: One‑dimensional array of time‑series values.
        n_steps: Number of time steps in each input sequence.

    Returns:
        Tuple (X, y) where X has shape (num_samples, n_steps, 1) and y has shape
        (num_samples, 1).
    """
    X = []
    y = []
    for i in range(len(data) - n_steps):
        X.append(data[i:i + n_steps])
        y.append(data[i + n_steps])
    X = np.array(X)
    y = np.array(y)
    return X[..., np.newaxis], y[..., np.newaxis]


def build_lstm_model(n_steps: int) -> tf.keras.Model:
    """Build an LSTM model for time series prediction.

    Args:
        n_steps: Number of time steps in the input sequence.

    Returns:
        Compiled Keras model.
    """
    model = tf.keras.Sequential([
        tf.keras.layers.LSTM(50, input_shape=(n_steps, 1)),
        tf.keras.layers.Dense(1)
    ])
    model.compile(optimizer="adam", loss="mse")
    return model


def forecast(model: tf.keras.Model, seed_sequence: np.ndarray, num_predictions: int = 50) -> np.ndarray:
    """Generate future values using the trained model.

    Args:
        model: Trained LSTM model.
        seed_sequence: Array of shape (n_steps, 1) used to start the forecast.
        num_predictions: Number of future steps to predict.

    Returns:
        Array of predicted values.
    """
    predictions = []
    current_seq = seed_sequence.copy()
    for _ in range(num_predictions):
        pred = model.predict(current_seq[np.newaxis, ...], verbose=0)[0, 0]
        predictions.append(pred)
        # Append prediction and remove first value to maintain sequence length
        current_seq = np.roll(current_seq, -1)
        current_seq[-1] = pred
    return np.array(predictions)


def main() -> None:
    data = generate_sine_wave(num_points=600)
    # Normalize data to [0, 1]
    min_val, max_val = data.min(), data.max()
    data_norm = (data - min_val) / (max_val - min_val)
    n_steps = 20
    X, y = prepare_sequences(data_norm, n_steps=n_steps)
    model = build_lstm_model(n_steps)
    model.fit(X, y, epochs=20, batch_size=32, verbose=0)
    # Use the last n_steps points as seed
    seed = data_norm[-n_steps:][..., np.newaxis]
    preds = forecast(model, seed_sequence=seed, num_predictions=50)
    # Denormalize predictions
    preds_denorm = preds * (max_val - min_val) + min_val
    print("Forecasted values (first 10):")
    print(preds_denorm[:10])


if __name__ == "__main__":  # pragma: no cover
    main()