"""GRU Sentiment Classifier

Trains a gated recurrent unit (GRU) network to perform binary sentiment
classification on a small dataset of sentences.  GRUs are recurrent networks
that use gating mechanisms to control information flow and have fewer
parameters than LSTMs【501703446364988†L147-L156】.
"""
from __future__ import annotations

import numpy as np
import tensorflow as tf
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.preprocessing.text import Tokenizer


def prepare_data() -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, int]:
    """Prepare sample sentiment data for training and testing.

    Returns:
        Tuple (X_train, y_train, X_test, y_test, vocab_size).
    """
    # Small dataset of sentences labelled as positive (1) or negative (0)
    sentences = [
        "This movie was fantastic and thrilling",  # pos
        "I loved the characters and the plot",  # pos
        "What a terrible and boring film",  # neg
        "The acting was awful and the story was dull",  # neg
        "An excellent movie with a heartwarming message",  # pos
        "I did not enjoy this movie at all",  # neg
    ]
    labels = [1, 1, 0, 0, 1, 0]
    # Split into train and test
    X_train_texts = sentences[:4]
    y_train = np.array(labels[:4])
    X_test_texts = sentences[4:]
    y_test = np.array(labels[4:])
    # Tokenize and pad sequences
    tokenizer = Tokenizer(oov_token="<UNK>")
    tokenizer.fit_on_texts(sentences)
    X_train_seq = tokenizer.texts_to_sequences(X_train_texts)
    X_test_seq = tokenizer.texts_to_sequences(X_test_texts)
    max_len = max(len(seq) for seq in X_train_seq + X_test_seq)
    X_train_pad = pad_sequences(X_train_seq, maxlen=max_len, padding="post")
    X_test_pad = pad_sequences(X_test_seq, maxlen=max_len, padding="post")
    vocab_size = len(tokenizer.word_index) + 1
    return X_train_pad, y_train, X_test_pad, y_test, vocab_size


def build_gru_model(vocab_size: int, max_len: int, embedding_dim: int = 16, gru_units: int = 32) -> tf.keras.Model:
    """Build a GRU model for binary sentiment classification.

    Args:
        vocab_size: Size of the vocabulary.
        max_len: Maximum input sequence length.
        embedding_dim: Embedding vector dimension.
        gru_units: Number of GRU units.

    Returns:
        Compiled Keras model.
    """
    model = tf.keras.Sequential([
        tf.keras.layers.Embedding(vocab_size, embedding_dim, input_length=max_len),
        tf.keras.layers.GRU(gru_units),
        tf.keras.layers.Dense(1, activation="sigmoid"),
    ])
    model.compile(optimizer="adam", loss="binary_crossentropy", metrics=["accuracy"])
    return model


def main() -> None:
    X_train, y_train, X_test, y_test, vocab_size = prepare_data()
    max_len = X_train.shape[1]
    model = build_gru_model(vocab_size, max_len)
    model.fit(X_train, y_train, epochs=20, batch_size=2, verbose=0)
    loss, acc = model.evaluate(X_test, y_test, verbose=0)
    print(f"Test accuracy: {acc:.3f}")


if __name__ == "__main__":  # pragma: no cover
    main()