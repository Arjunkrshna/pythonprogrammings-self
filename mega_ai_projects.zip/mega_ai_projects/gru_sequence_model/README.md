# GRU Sequence Model

## Aim

This project implements a **gated recurrent unit (GRU)** network for sentiment
classification on a small set of sentences.  GRUs are a variant of recurrent
neural networks with gating mechanisms that balance information flow; they have
fewer parameters than LSTM networks, making them more efficient【501703446364988†L147-L156】.

The goal is to classify short movie review sentences as positive or negative.
The dataset is tiny and intended only to illustrate the end‑to‑end pipeline of
tokenizing text, building a GRU model, training and evaluating performance.

## Prerequisites

* **Python 3.9+**
* [TensorFlow](https://www.tensorflow.org/): `pip install tensorflow`

## Tools & Libraries

| Tool | Purpose |
| --- | --- |
| `tensorflow.keras` | Provides tokenization utilities and GRU layers. |

## Workflow

1. **Prepare data** – Define a small list of sentences labeled as positive or
   negative.  Use Keras `Tokenizer` to convert sentences into sequences of
   integer tokens and pad them to a uniform length.
2. **Define model** – Build a sequential model with an embedding layer, a GRU
   layer and a dense output layer with sigmoid activation for binary
   classification.  GRUs efficiently capture sequential patterns with gating
   mechanisms【501703446364988†L147-L156】.
3. **Train** – Train the model on the prepared data using binary cross‑entropy
   loss.
4. **Evaluate** – Evaluate the model on a held‑out test set and print accuracy.

## Running the Project

```bash
# Install dependencies
pip install tensorflow

# Train and evaluate the GRU sentiment classifier
python main.py
```

## References

* Coursera. “What Is a Recurrent Neural Network?”.  Notes that GRUs work
  similarly to LSTM networks but use a more efficient architecture with fewer
  parameters【501703446364988†L147-L156】.