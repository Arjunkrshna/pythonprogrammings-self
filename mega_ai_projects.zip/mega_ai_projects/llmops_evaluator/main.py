"""LLMOps Evaluator

This module implements a simple evaluation pipeline for large language models.
LLMOps involves practices and tools for managing LLMs in production, including
evaluation and monitoring【870375802973421†L182-L205】.  Here we focus on the
evaluation step: given a set of questions and reference answers, we generate
answers using a pre‑trained model and compute quantitative metrics.

Usage:
    python main.py --model distilbert-base-uncased --output results.json

The script prints BLEU and ROUGE scores and writes a JSON file containing the
metric results and sample predictions.
"""
from __future__ import annotations

import argparse
import json
import sys
from typing import List, Dict, Optional

try:
    import evaluate  # type: ignore
    from transformers import pipeline
except ImportError as e:  # pragma: no cover
    raise ImportError("Please install transformers and evaluate: pip install transformers evaluate") from e


def load_dataset() -> List[Dict[str, str]]:
    """Load or define a small evaluation dataset.

    Returns a list of dictionaries with `prompt` and `answer` keys.  You can
    replace this with loading a dataset from the `datasets` library.
    """
    return [
        {
            "prompt": "What is the capital of France?",
            "answer": "The capital of France is Paris."
        },
        {
            "prompt": "Who wrote the play 'Romeo and Juliet'?",
            "answer": "William Shakespeare wrote the play 'Romeo and Juliet'."
        },
        {
            "prompt": "What is the boiling point of water at sea level?",
            "answer": "The boiling point of water at sea level is 100 degrees Celsius."
        }
    ]


def generate_predictions(prompts: List[str], model_name: str) -> List[str]:
    """Generate answers to prompts using a specified model.

    Args:
        prompts: List of prompt strings.
        model_name: Hugging Face model identifier; for question answering tasks you
            might use a text‑generation model or a sequence‑to‑sequence model.

    Returns:
        List of generated answer strings.
    """
    generator = pipeline("text-generation", model=model_name)
    outputs = generator(prompts, max_length=64, do_sample=False)
    # outputs is a list of dicts, each with 'generated_text'
    return [out["generated_text"].strip() for out in outputs]


def compute_metrics(references: List[str], predictions: List[str]) -> Dict[str, float]:
    """Compute BLEU and ROUGE-L metrics for predictions versus references.

    Args:
        references: List of reference (ground truth) answers.
        predictions: List of predicted answers.

    Returns:
        Dictionary of metric names to scores.
    """
    bleu = evaluate.load("bleu")
    rouge = evaluate.load("rouge")
    bleu_score = bleu.compute(predictions=predictions, references=[[ref] for ref in references])["bleu"]
    rouge_scores = rouge.compute(predictions=predictions, references=references)
    # We use ROUGE-L f-measure as a summary statistic
    return {
        "bleu": bleu_score,
        "rougeL": rouge_scores.get("rougeL", 0.0)
    }


def parse_args(argv: Optional[List[str]] = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Evaluate a language model on simple QA pairs.")
    parser.add_argument(
        "--model",
        type=str,
        default="gpt2",
        help="Hugging Face model name (e.g. gpt2, google/flan-t5-small).",
    )
    parser.add_argument(
        "--output",
        type=str,
        default="",
        help="Optional path to save evaluation results as JSON.",
    )
    return parser.parse_args(argv)


def main(argv: Optional[List[str]] = None) -> int:
    args = parse_args(argv)
    dataset = load_dataset()
    prompts = [item["prompt"] for item in dataset]
    references = [item["answer"] for item in dataset]
    try:
        predictions = generate_predictions(prompts, args.model)
    except Exception as exc:  # pragma: no cover
        print(f"Error generating predictions: {exc}", file=sys.stderr)
        return 1
    metrics = compute_metrics(references, predictions)
    print("Evaluation Metrics:")
    for k, v in metrics.items():
        print(f"  {k}: {v:.4f}")
    # Optionally save results
    if args.output:
        data = {
            "model": args.model,
            "metrics": metrics,
            "predictions": [
                {"prompt": p, "reference": ref, "prediction": pred}
                for p, ref, pred in zip(prompts, references, predictions)
            ],
        }
        with open(args.output, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
        print(f"Results saved to {args.output}")
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())