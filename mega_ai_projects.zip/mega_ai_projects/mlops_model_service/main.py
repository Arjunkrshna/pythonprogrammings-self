"""MLOps Model Service

This script trains a simple classifier on the Iris dataset and serves it via
a FastAPI web service.  MLOps integrates model development with operations by
automating training, deployment and monitoring【708550180055594†L509-L520】.  The script supports two
commands:

* `train`: Train a logistic regression model, evaluate it and save to `model.joblib`.
* `serve`: Launch a FastAPI application that loads the saved model and exposes
  a `/predict` endpoint.

Usage:
    python main.py train
    python main.py serve
"""
from __future__ import annotations

import argparse
import joblib
import os
import sys
from typing import List, Optional

from sklearn.datasets import load_iris
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score


def train_model(model_path: str = "model.joblib") -> None:
    """Train and save a logistic regression classifier on the Iris dataset.

    Args:
        model_path: Path to save the serialized model.
    """
    data = load_iris()
    X_train, X_test, y_train, y_test = train_test_split(
        data.data, data.target, test_size=0.2, random_state=42, stratify=data.target
    )
    clf = LogisticRegression(max_iter=200)
    clf.fit(X_train, y_train)
    y_pred = clf.predict(X_test)
    acc = accuracy_score(y_test, y_pred)
    print(f"Model trained. Test accuracy: {acc:.3f}")
    joblib.dump(clf, model_path)
    print(f"Model saved to {model_path}")


def serve_model(model_path: str = "model.joblib") -> None:
    """Serve the trained model via a FastAPI application.

    Args:
        model_path: Path to the serialized model file.
    """
    try:
        from fastapi import FastAPI
        from pydantic import BaseModel
        import uvicorn  # type: ignore
    except ImportError as e:  # pragma: no cover
        raise ImportError(
            "Please install fastapi, pydantic and uvicorn: pip install fastapi uvicorn pydantic"
        ) from e

    if not os.path.exists(model_path):
        raise FileNotFoundError(
            f"Model file '{model_path}' not found. Please run 'python main.py train' first."
        )
    model = joblib.load(model_path)

    class Features(BaseModel):
        features: List[float]

    app = FastAPI(title="Iris Classifier API")

    @app.post("/predict")
    def predict(features: Features) -> dict[str, int]:  # pragma: no cover
        if len(features.features) != model.coef_.shape[1]:
            return {"error": f"Expected {model.coef_.shape[1]} features"}
        prediction = int(model.predict([features.features])[0])
        return {"prediction": prediction}

    # Run the server
    uvicorn.run(app, host="0.0.0.0", port=8000)


def parse_args(argv: Optional[List[str]] = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Train and serve a simple Iris classifier.")
    parser.add_argument("command", choices=["train", "serve"], help="train or serve the model")
    parser.add_argument(
        "--model",
        type=str,
        default="model.joblib",
        help="Path to save/load the model file (default: model.joblib)",
    )
    return parser.parse_args(argv)


def main(argv: Optional[List[str]] = None) -> int:
    args = parse_args(argv)
    if args.command == "train":
        train_model(args.model)
    elif args.command == "serve":
        serve_model(args.model)
    else:  # pragma: no cover
        print(f"Unknown command: {args.command}")
        return 1
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())