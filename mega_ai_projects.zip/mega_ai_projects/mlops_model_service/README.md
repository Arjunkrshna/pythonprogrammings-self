# MLOps Model Service

## Aim

This example demonstrates an **MLOps** workflow: training a simple machine
learning model and serving it via a REST API.  MLOps combines machine
learning, software engineering and DevOps practices to streamline the end‑to‑end
ML lifecycle【708550180055594†L509-L520】.  It emphasizes automation, collaboration and
continuous improvement across data preparation, model development, deployment
and monitoring【708550180055594†L509-L520】.

Here we implement a logistic regression classifier on the classic Iris dataset
using scikit‑learn, save the trained model and serve predictions through a
FastAPI web server.  This illustrates key MLOps concepts such as model
versioning, reproducibility and deploying ML models as services.

## Prerequisites

* **Python 3.9+**
* [scikit‑learn](https://scikit-learn.org/) and [joblib](https://joblib.readthedocs.io/):
  `pip install scikit-learn joblib`
* [FastAPI](https://fastapi.tiangolo.com/) and [uvicorn](https://www.uvicorn.org/):
  `pip install fastapi uvicorn`

## Tools & Libraries

| Tool | Purpose |
| --- | --- |
| `scikit-learn` | Trains the logistic regression classifier. |
| `joblib` | Serializes the model to disk. |
| `FastAPI` | Builds a lightweight REST API for serving predictions. |
| `uvicorn` | ASGI server used to run the FastAPI app. |

## Workflow

1. **Training** – Load the Iris dataset, split it into train/test sets and fit a
   logistic regression model.  Save the trained model to disk (`model.joblib`).
2. **Service** – Define a FastAPI application with an endpoint `/predict` that
   accepts feature values and returns the predicted class label.  On startup the
   app loads the saved model.
3. **Deployment** – Run the API locally using `uvicorn`.  In a production
   MLOps setting you might containerize the service, deploy it to a cloud
   platform and integrate with monitoring tools.

## Running the Project

```bash
# Install dependencies
pip install scikit-learn joblib fastapi uvicorn

# Train and save the model
python main.py train

# Serve the model via API (this command starts a server; use Ctrl+C to stop)
python main.py serve

# In another terminal, send a request (example using curl)
curl -X POST "http://127.0.0.1:8000/predict" \
     -H "Content-Type: application/json" \
     -d '{"features": [5.1, 3.5, 1.4, 0.2]}'
```

## Extending

To expand this MLOps example you could:

* Use a more complex dataset and model (e.g. gradient boosting or neural networks).
* Integrate experiment tracking (e.g. MLflow, Weights & Biases) to log metrics and
  parameters.
* Add authentication and request logging to the API.
* Set up continuous integration/continuous deployment (CI/CD) pipelines to
  automatically test and deploy new model versions【708550180055594†L509-L520】.

## References

* NVIDIA Glossary. “What is Machine Learning Operations (MLOps)?”.
  Describes MLOps as a set of practices and principles that streamline the
  development, deployment and maintenance of machine learning models, emphasising
  automation, collaboration and continuous improvement【708550180055594†L509-L520】.