"""ANN Classifier

Train a feed‑forward neural network on the Iris dataset.  An FNN (feedforward
neural network) processes inputs through a series of layers without any
recurrence or loops【681983870753496†L86-L110】.  Training involves forward propagation to
compute predictions, calculating the loss and using backpropagation to adjust
weights【681983870753496†L129-L145】.
"""
from __future__ import annotations

import numpy as np
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
import tensorflow as tf


def build_model(input_dim: int, num_classes: int) -> tf.keras.Model:
    """Build a simple feedforward neural network using Keras.

    Args:
        input_dim: Number of input features.
        num_classes: Number of output classes.

    Returns:
        Compiled Keras model ready for training.
    """
    model = tf.keras.Sequential([
        tf.keras.layers.InputLayer(input_shape=(input_dim,)),
        tf.keras.layers.Dense(16, activation="relu"),
        tf.keras.layers.Dense(num_classes, activation="softmax"),
    ])
    model.compile(
        optimizer="adam",
        loss="categorical_crossentropy",
        metrics=["accuracy"],
    )
    return model


def main() -> None:
    iris = load_iris()
    X_train, X_test, y_train, y_test = train_test_split(
        iris.data, iris.target.reshape(-1, 1), test_size=0.2, random_state=42, stratify=iris.target
    )
    # One-hot encode labels
    encoder = OneHotEncoder(sparse_output=False)
    y_train_encoded = encoder.fit_transform(y_train)
    y_test_encoded = encoder.transform(y_test)
    model = build_model(input_dim=iris.data.shape[1], num_classes=len(iris.target_names))
    # Train model
    history = model.fit(X_train, y_train_encoded, epochs=50, batch_size=16, validation_split=0.1, verbose=0)
    # Evaluate
    loss, acc = model.evaluate(X_test, y_test_encoded, verbose=0)
    print(f"Test accuracy: {acc:.3f}")


if __name__ == "__main__":  # pragma: no cover
    main()