# ANN Classifier

## Aim

This project builds a simple **feed‑forward neural network** (artificial
neural network or ANN) for classifying data.  A feedforward neural network
consists of an input layer, one or more hidden layers and an output layer; data
flows strictly from input to output without loops【681983870753496†L86-L110】.  The
model learns by adjusting weights on connections between neurons through
backpropagation【681983870753496†L129-L145】.

We use the **Iris** dataset to train a classifier that predicts the species of a
flower based on its sepal and petal dimensions.  This project illustrates
foundational deep learning concepts such as network architecture, activation
functions and training loops.

## Prerequisites

* **Python 3.9+**
* [TensorFlow](https://www.tensorflow.org/) (includes Keras): `pip install tensorflow`.
* (Optional) `scikit-learn` for loading the Iris dataset: `pip install scikit-learn`.

## Tools & Libraries

| Tool | Purpose |
| --- | --- |
| `tensorflow.keras` | Builds and trains the neural network. |
| `scikit-learn` | Loads the Iris dataset and splits it into train/test sets. |

## Workflow

1. **Load data** – Use scikit‑learn to load the Iris dataset and split it into
   training and test sets.  Convert labels to one‑hot vectors.
2. **Define model** – Create a sequential model with Dense layers.  The input
   layer has 4 units (one for each feature), a hidden layer uses a non‑linear
   activation like ReLU and the output layer has 3 units with softmax
   activation.
3. **Compile** – Choose a loss function (categorical cross‑entropy), optimizer
   (Adam) and metrics (accuracy).
4. **Train** – Fit the model to the training data for a number of epochs.
5. **Evaluate** – Evaluate the model on the test set and print accuracy.

## Running the Project

```bash
# Install dependencies
pip install tensorflow scikit-learn

# Train and evaluate the ANN classifier
python main.py
```

## References

* GeeksforGeeks. “Feedforward Neural Network.” Defines FNNs as neural networks
  where information flows in a single direction from input through hidden layers
  to output and explains their layer structure【681983870753496†L86-L110】.  The article
  describes training with forward propagation, loss calculation and
  backpropagation【681983870753496†L129-L145】.